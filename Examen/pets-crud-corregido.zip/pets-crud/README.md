# Sistema de Gestión de Mascotas — Pets CRUD

Este módulo permite gestionar mascotas mediante operaciones CRUD:

- Crear mascotas
- Listar mascotas
- Consultar una mascota por ID
- Actualizar datos de una mascota
- Eliminar mascotas
- Ver estadísticas básicas

Además, se conecta con `epn-event-manager` para enviar eventos cuando se realiza una acción sobre una mascota.

## Tecnologías usadas

- Node.js 22.5 o superior
- Express
- SQLite mediante `node:sqlite`
- HTML, CSS y JavaScript
- Axios
- ESLint
- node:test

## Variables de entorno

Puedes crear un archivo `.env` o definir estas variables desde la terminal:

| Variable | Valor por defecto | Descripción |
|---|---|---|
| `PORT` | `4002` | Puerto donde corre el CRUD de mascotas. |
| `PETS_DB_PATH` | `./db/pets.sqlite` | Ruta de la base SQLite. |
| `EVENT_MANAGER_URL` | `http://localhost:3000/events` | URL para enviar eventos al Event Manager. |
| `EVENT_MANAGER_HEALTH_URL` | `http://localhost:3000/health` | URL para verificar el estado del Event Manager. |
| `EVENT_TIMEOUT_MS` | `2500` | Tiempo máximo de espera para el Event Manager. |
| `ALLOWED_ORIGINS` | vacío | Lista de orígenes permitidos para CORS, separados por coma. |

## Ejecución

Instalar dependencias:

```bash
npm install
```

Iniciar el servidor:

```bash
npm start
```

Abrir en el navegador:

```text
http://localhost:4002
```

## Comandos de verificación

Revisar sintaxis:

```bash
npm run check
```

Ejecutar ESLint:

```bash
npm run lint
```

Ejecutar pruebas:

```bash
npm test
```

## Endpoints principales

| Método | Ruta | Descripción |
|---|---|---|
| `GET` | `/health` | Verifica API, base de datos y conexión con Event Manager. |
| `GET` | `/pets` | Lista todas las mascotas. |
| `GET` | `/pets/:id` | Consulta una mascota por ID. |
| `POST` | `/pets` | Registra una mascota. |
| `PUT` | `/pets/:id` | Actualiza una mascota. |
| `DELETE` | `/pets/:id` | Elimina una mascota. |
| `GET` | `/pets/stats` | Devuelve estadísticas generales. |

## Mantenimiento aplicado

### Correctivo

- Se corrigió la documentación del puerto: el servidor usa `4002`.
- Se eliminó la URL fija del frontend. Ahora usa `window.location.origin`.
- Se protegió el renderizado de datos para evitar inyección HTML/XSS.
- Se evitó que el CRUD quede esperando al Event Manager para responder al usuario.

### Preventivo

- Se agregó configuración de CORS mediante `ALLOWED_ORIGINS`.
- Se ocultó la ruta física de la base de datos en `/health`.
- Se agregó una suite de pruebas automatizadas con `node:test`.
- Se documentaron variables de entorno.

### Perfectivo

- El frontend ahora consume `/pets/stats` para mostrar estadísticas desde el backend.
- Se mejoró la documentación de instalación, ejecución y endpoints.

### Adaptativo

- El frontend ya no depende de `localhost:4002` escrito directamente.
- El sistema puede adaptarse mejor a otros puertos, rutas de base de datos y URLs del Event Manager.
