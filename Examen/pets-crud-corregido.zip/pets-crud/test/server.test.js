const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'pets-crud-test-'));
process.env.PETS_DB_PATH = path.join(tempDir, 'pets.sqlite');
process.env.EVENT_MANAGER_URL = 'http://127.0.0.1:9/events';
process.env.EVENT_MANAGER_HEALTH_URL = 'http://127.0.0.1:9/health';

const {
  validatePet,
  normalizeSpecies,
  normalizeStatus,
  insertPet,
  findPetById,
  updatePet,
  deletePetById,
  getPetStats,
} = require('../server');

test('validatePet rechaza campos obligatorios e inválidos', () => {
  const errors = validatePet({
    name: '',
    species: 'dragon',
    owner: '',
    age: '2.5',
    status: 'desconocido',
  });

  assert.ok(errors.includes('name es obligatorio'));
  assert.ok(errors.includes('species inválida'));
  assert.ok(errors.includes('owner es obligatorio'));
  assert.ok(errors.includes('age debe ser un número entero entre 0 y 50'));
  assert.ok(errors.includes('status inválido'));
});

test('normaliza especie y estado', () => {
  assert.equal(normalizeSpecies(' Perro '), 'perro');
  assert.equal(normalizeSpecies('tortuga'), 'otro');
  assert.equal(normalizeStatus(' perdido '), 'perdido');
  assert.equal(normalizeStatus('sin_estado'), 'activo');
});

test('realiza ciclo CRUD básico con SQLite temporal', () => {
  const created = insertPet({
    name: 'Max',
    species: 'perro',
    breed: 'Labrador',
    age: 3,
    owner: 'Gabriela',
    phone: '0999999999',
    status: 'activo',
    description: 'Mascota de prueba',
  });

  assert.match(created.id, /^PET-\d{4}$/);
  assert.equal(created.name, 'Max');

  const found = findPetById(created.id);
  assert.equal(found.owner, 'Gabriela');

  const updated = updatePet(created.id, {
    age: 4,
    status: 'en_tratamiento',
  });

  assert.equal(updated.age, 4);
  assert.equal(updated.status, 'en_tratamiento');

  const stats = getPetStats();
  assert.deepEqual(stats, {
    total: 1,
    active: 0,
    treatment: 1,
    lost: 0,
  });

  const deleted = deletePetById(created.id);
  assert.equal(deleted.id, created.id);
  assert.equal(findPetById(created.id), null);
});
